<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sprawdzian 27.04</title>
</head>
<body>
    <form action="#" method="post">
        imie: <input type="text" name="imie"><br><br>
        <input type="submit" value="WYŚLIJ">
    </form>
    <?php


        $polaczenie = mysqli_connect("localhost","root","","szkola");

        if (mysqli_connect_errno())
        {
            echo ("wystapił błąd");
        }

        $query = "SELECT * from uczen";
        $result = mysqli_query($polaczenie, $query);

            echo("<table>");
            echo("<tr><td>L.p</td><td>Imię</td><td>Nazwisko</td><td>Średnia</td></tr>");
        for ($i=1; $i <= mysqli_num_rows($result); $i++) 
        { 
        $dane = mysqli_fetch_assoc($result);

            echo("<tr><td>${i}.</td><td>dane['imie']</td><td>dane['nazwisko']</td><td>dane['srednia']</td></tr>");
        }
            echo("</table>");

        $polaczenie->close();
    ?>
</body>
</html>