<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadanie2</title>
</head>
<body>

<?php
$nowe;
$polaczenie = mysqli_connect("localhost", "root", "", "szkola");
if (isset($_GET['imie']) && isset($_GET['nazwisko']) && isset($_GET['srednia']) && isset($_GET['klasa_id'])){
    $imie = $_GET['imie'];
    $nazwisko = $_GET['nazwisko'];
    $srednia = $_GET['srednia'];
    $klasa_id = $_GET['klasa_id'];
    $nowe = "INSERT INTO uczen (imie, nazwisko, srednia, klasa_id) VALUES ('${imie}', '${nazwisko}', '${srednia}', '${klasa_id}')";
    echo ("<h1>".$nowe."</h1");
    mysqli_query($polaczenie, $nowe);
}

echo<<<formularz
<form method="get">
<h3>Podaj imię ucznia:</h3> <input type="text" name="imie"><br><br>
<h3>Podaj nazwisko ucznia:</h3> <input type="text" name="nazwisko"><br><br>
<h3>Podaj średnią ucznia:</h3> <input type="text" name="srednia"><br><br>
<h3>Wybierz klasę ucznia:</h3> <select name="klasa_id">
formularz;

$result = mysqli_query($polaczenie, "SELECT * FROM klasa");
for ($i=1; $i <= mysqli_num_rows($result); $i++)
{
$dane = mysqli_fetch_assoc($result);

    echo("<option value=\"${dane['id']}\">${dane['nazwa']}</option>");
}

echo('</select><input type="submit" value="Dodaj ucznia"></form>');

mysqli_close($polaczenie);
?>
    
</body>
</html>